public class SinglyLinkedList<E> implements Cloneable{
    private static class Node<E> {
        private E element;
        private Node<E> next;

        public Node(E e, Node<E> n) {
            this.element = e;
            this.next = n;
        }

        public E getElement() {
            return this.element;
        }

        public Node<E> getNext() {
            return this.next;
        }

        public void setNext(Node<E> n) {
            next = n;
        }
    }

    private Node<E> head = null;
    private Node<E> tail = null;
    private int size = 0;

    public SinglyLinkedList() {
    }

    public int size() {
        return this.size;
    }

    public boolean isEmpty() {
        return this.size == 0;
    }

    public E first() {
        if (isEmpty()) {
            return null;
        }
        return head.getElement();
    }

    public E last() {
        if (isEmpty()) {
            return null;
        }
        return tail.getElement();
    }

    // update methods
    public void addFirst(E e) {
        head = new Node<>(e, head);
        if (size == 0) {
            tail = head;
        }
        size++;
    }

    public void addLast(E e) {
        Node<E> newest = new Node<>(e, null);
        if (isEmpty()) {
            head = newest;
        } else {
            tail.setNext(newest);
        }
        tail = newest;
        size++;
    }

    public E removeFirst() {
        if (isEmpty()) {
            return null;
        }
        E answer = head.getElement();
        head = head.getNext();
        size--;
        if (size == 0) {
            tail = null;
        }
        return answer;
    }

    /*
     *Override the equal method
     *Two SSLs considered to be equal if 
     *   They have the same number of nodes and
     *   Each node data must be identical
    */
    @Override
    public boolean equals(Object obj) {
        if (obj == null) return false;
        
        if (this.getClass() != obj.getClass()) return false;
        
        SinglyLinkedList other = (SinglyLinkedList) obj;  // use nonparameterized type // raw types
        if (size != other.size) return false;
        
        Node walkA = this.head;  // traverse the primary list
        Node walkB = other.head;  // traverse the secondary list
        
        while (walkA != null) {
            if (!walkA.getElement().equals(walkB.getElement()))     return false;
            walkA = walkA.getNext();
            walkB = walkB.getNext();
        }
        
        return true;  // if we reach this, everything matched successfully
    }

    //Override the clone() method to make a deep copy of the current SLL
    @Override
    protected Object clone() throws CloneNotSupportedException {
        // always use inherited Object.clone() to create the initial copy
        SinglyLinkedList<E> other = (SinglyLinkedList<E>) super.clone();  // safe cast
        if (size > 0) {
            other.head = new Node<>(head.getElement(), null);
            Node<E> walk = head.getNext();
            Node<E> otherTail = other.head;
            while (walk != null) {
                Node<E> newest = new Node<>(walk.getElement(), null);
                otherTail.setNext(newest);
                otherTail = newest;
                walk = walk.getNext();
            }
        }
        return other;
    }
}
